import os
import glob
import subprocess
import sys
import re
import pty
from tqdm import tqdm
import questionary
from questionary import Choice, Style

# 1. 优化自定义终端交互样式（调亮所有色彩）
custom_style = Style([
    ('qmark', 'fg:#ff5f87 bold'),       # 问号标识：亮粉红
    ('question', 'fg:#ffffff bold'),    # 问题文本：纯白加粗
    ('selected', 'fg:#00ffff bold'),    # 光标停留在列表上的文字：高亮亮青
    ('pointer', 'fg:#ff007f bold'),     # 光标箭头：亮粉
    ('highlighted', 'fg:#00ffff bold'),  # 高亮项：高亮亮青
    ('answer', 'fg:#00ff87 bold'),      # 确认后的回答文本（如 Yes）：亮荧光绿（替代原先暗沉的紫色）
])

def run_rclone_with_bar(local_dir, remote_path, desc="正在传输"):
    """
    基于 PTY 的实时 rclone 传输（最终稳定版）
    关键修复：添加 --stats-log-level NOTICE，确保进度正常输出
    """
    command = [
        "rclone", "copy", local_dir, remote_path,
        "--transfers", "16",
        "--checkers", "16",
        "--stats", "1s",
        "--stats-one-line",
        "--stats-log-level", "NOTICE",   # ★ 关键！没有这行就永远不出进度
        "--no-traverse",
        "--s3-disable-checksum",
        "--ignore-checksum",
        "--contimeout", "10s",
        "--low-level-retries", "3"
    ]

    percent_regex = re.compile(r"(\d+)%")
    speed_regex   = re.compile(r"([\d.]+\s*[kKMGT]?i?B(?:ytes)?/s)", re.IGNORECASE)
    eta_regex     = re.compile(r"ETA\s+([^\s,]+)", re.IGNORECASE)
    ansi_escape   = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')

    pbar = tqdm(
        total=100,
        desc=desc,
        ascii="▱▰",
        dynamic_ncols=True,
        bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt}% [{postfix}]"
    )
    pbar.set_postfix_str("⚡ 连接中... | ETA --")
    last_percent = 0

    master_fd, slave_fd = pty.openpty()

    try:
        process = subprocess.Popen(
            command,
            stdout=slave_fd,
            stderr=slave_fd,
            close_fds=True
        )
        os.close(slave_fd)

        buffer = ""
        while True:
            try:
                data = os.read(master_fd, 4096)
                if not data:
                    break

                buffer += data.decode('utf-8', errors='ignore')

                while '\n' in buffer or '\r' in buffer:
                    pos_r = buffer.find('\r')
                    pos_n = buffer.find('\n')
                    if pos_r != -1 and pos_n != -1:
                        split_pos = min(pos_r, pos_n)
                    else:
                        split_pos = max(pos_r, pos_n)

                    line = buffer[:split_pos]
                    buffer = buffer[split_pos + 1:]

                    clean_line = ansi_escape.sub('', line).strip()
                    if not clean_line:
                        continue

                    # 1. 进度百分比
                    pct_match = percent_regex.search(clean_line)
                    if pct_match:
                        current_percent = int(pct_match.group(1))
                        if 0 <= current_percent <= 100 and current_percent > last_percent:
                            pbar.update(current_percent - last_percent)
                            last_percent = current_percent

                    # 2. 网速 + ETA
                    speed_match = speed_regex.search(clean_line)
                    eta_match   = eta_regex.search(clean_line)

                    if speed_match or eta_match:
                        speed_str = speed_match.group(1) if speed_match else "-- B/s"
                        eta_str   = f"ETA {eta_match.group(1)}" if eta_match else "ETA --"
                        pbar.set_postfix_str(f"⚡ {speed_str} | {eta_str}")

            except OSError:
                break

        process.wait()
        try:
            os.close(master_fd)
        except Exception:
            pass

        if process.returncode == 0:
            if last_percent < 100:
                pbar.update(100 - last_percent)
            pbar.set_postfix_str("⚡ 完成 | ETA 0s")
            pbar.refresh()
            pbar.close()
            return True
        else:
            pbar.close()
            print(f"\n❌ 传输至 {remote_path} 失败，进程非正常退出（code={process.returncode}）。")
            return False

    except KeyboardInterrupt:
        pbar.close()
        try:
            os.close(master_fd)
        except Exception:
            pass
        process.terminate()
        print(f"\n🛑 收到终止信号，当前传输已取消。")
        return False

def upload_mode_r2(folder_path):
    """
    手动选择 ZIP 压缩包并自动分流上传（高光亮高对比度样式）
    """
    search_path = os.path.join(folder_path, "*.zip")
    zip_files = glob.glob(search_path)

    if not zip_files:
        print(f"❌ 在文件夹中未找到任何 .zip 文件")
        return False

    zip_files.sort(key=os.path.getmtime, reverse=True)

    choices = []
    for idx, fpath in enumerate(zip_files):
        fname = os.path.basename(fpath)
        if idx == 0:
            display_title = f"📦 {fname}  [最新]"
        else:
            display_title = f"📦 {fname}"
        
        choices.append(Choice(title=display_title, value=fpath))

    # 使用高亮 ANSI ANSI 颜色代码（1;93m 亮黄 / 1;92m 亮绿）
    print("\n💡 使用 [\033[1;93m↑/↓ 方向键\033[0m] 移动高亮光标，按 [\033[1;92mEnter 回车\033[0m] 选中：\n")
    
    try:
        selected_zip_path = questionary.select(
            "请选择要上传的压缩包:",
            choices=choices,
            style=custom_style,
            use_indicator=True
        ).ask()

        if not selected_zip_path:
            print("\n🛑 操作已取消，程序退出。")
            return False

    except KeyboardInterrupt:
        print(f"\n\n🛑 收到终止信号，上传已取消。")
        return False

    file_name = os.path.basename(selected_zip_path)

    # 路由规则匹配
    if "ZrSetuTime" in file_name:
        target_path = "r2:setutime/zrsetu_zip/"
        display_folder = "/zrsetu_zip/"
    elif "SetuTime" in file_name:
        target_path = "r2:setutime/setu_zip/"
        display_folder = "/setu_zip/"
    else:
        target_path = "r2:setutime/"
        display_folder = "存储桶最外层根目录"

    # 2. 优化终端 print 输出（高亮亮黄背景与加粗亮绿）
    print(f"\n🎯 选中的文件: \033[1;97;45m {file_name} \033[0m") # 采用紫红底白字高亮，极其清晰
    print(f"📁 匹配目标路径: \033[1;96m{display_folder}\033[0m")  # 高亮亮青色
    print("-" * 50)

    confirm = questionary.confirm(
        "👉 是否确认开始上传？", 
        default=True,
        style=custom_style
    ).ask()

    if not confirm:
        print("\n🛑 已取消上传操作。")
        return False

    print(f"\n🚀 正在启动多线程高速上传 ➡️ 目标位置: \033[1;92m{display_folder}\033[0m")
    
    success = run_rclone_with_bar(selected_zip_path, target_path, desc="📦 ZIP 上传进度")
    if success:
        print("\n✅ 归类同步完成！")
        return True
    return False

if __name__ == "__main__":
    print("\n==========================================================")
    print("🤖 启动 R2 存储 —— 高亮交互式 ZIP 压缩包分流服务")
    print("==========================================================")
    
    upload_mode_r2("/Users/yu7our/python")
    print("\n👋 任务执行完毕，程序安全退出。")