import os
import re
import sys
import shutil
import subprocess
from PIL import Image

def get_script_directory():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def natural_sort_key(file_info):
    filename = file_info[1]
    def convert(text):
        return int(text) if text.isdigit() else text.lower()
    def alphanum_key(key):
        return [convert(c) for c in re.split('([0-9]+)', key)]
    return alphanum_key(filename)

def get_all_files_recursive(directory):
    if not os.path.exists(directory):
        return [], False
    
    image_exts = ('.jpg', '.jpeg', '.png', '.webp', '.bmp', '.tif', '.tiff')
    video_exts = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm')
    
    all_files = []
    has_video = False
    
    for root, dirs, files in os.walk(directory):
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            if ext in image_exts:
                full_path = os.path.join(root, f)
                rel_path = os.path.relpath(full_path, directory)
                all_files.append((full_path, rel_path, f, 'image'))
            elif ext in video_exts:
                full_path = os.path.join(root, f)
                rel_path = os.path.relpath(full_path, directory)
                all_files.append((full_path, rel_path, f, 'video'))
                has_video = True
                
    all_files.sort(key=natural_sort_key)
    return all_files, has_video

def print_progress(current, total, bar_length=40):
    """标准的单行动态进度条"""
    percent = float(current) / total if total > 0 else 1
    arrow = '=' * int(round(percent * bar_length) - 1) + '>'
    spaces = ' ' * (bar_length - len(arrow))
    sys.stdout.write(f"\r处理进度: [{arrow}{spaces}] {int(percent * 100)}% ({current}/{total})")
    sys.stdout.flush()

def convert_to_mp4(input_path, output_path):
    """调用 ffmpeg 将视频转换为 MP4 格式"""
    cmd = [
        'ffmpeg', '-y', '-i', input_path, 
        '-c:v', 'libx264', '-pix_fmt', 'yuv420p', 
        '-c:a', 'aac', '-loglevel', 'error'
    ]
    subprocess.run(cmd, check=True)

def process_files():
    script_dir = get_script_directory()
    target_dir = os.path.join(script_dir, "无水印原图")
    
    print("=" * 60)
    print(" 媒体资产处理工具 | 极速扁平化、脱敏与规范化命名 ")
    print("=" * 60)

    if not os.path.exists(target_dir):
        print(f" 错误：找不到文件夹 '{target_dir}'")
        input("\n按回车键退出...")
        return

    # 1. 扫描文件并检测是否有视频
    files_info, has_video = get_all_files_recursive(target_dir)
    total = len(files_info)
    if total == 0:
        print(" 提示：未发现支持的图片或视频文件。")
        input("\n按回车键退出...")
        return

    # 2. 智能期号交互 (自动读取并记录 .last_issue.txt)
    issue_num = ""
    if has_video:
        issue_file_path = os.path.join(script_dir, ".last_issue.txt")
        last_issue = 0
        
        # 尝试读取上次的期号
        if os.path.exists(issue_file_path):
            try:
                with open(issue_file_path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    # 提取文本中的数字部分
                    match = re.search(r'\d+', content)
                    if match:
                        last_issue = int(match.group())
            except Exception:
                pass
        
        next_issue = last_issue + 1
        
        print("\n" + "=" * 40)
        print(" 📽️ 检测到视频文件！")
        if last_issue > 0:
            print(f" 文本读取上一期号 : {last_issue}")
        print(f" 建议本期使用期号 : {next_issue}")
        print("=" * 40)
        
        user_input = input("请按 [回车键] 确认使用建议期号，或手动输入新期号: ").strip()
        
        if user_input == "":
            issue_num = str(next_issue)
        else:
            issue_num = user_input
            
        # 将本次确认的期号持久化保存，供下一次使用
        try:
            with open(issue_file_path, "w", encoding="utf-8") as f:
                f.write(issue_num)
        except Exception as e:
            print(f" 提示：无法保存期号记录到 .last_issue.txt ({e})")

    print("\n正在处理，请稍候...")
    print_progress(0, total)

    img_index = 1
    vid_index = 1
    success_count = 0

    # 3. 核心流式处理环
    for i, (old_path, rel_path, old_name, file_type) in enumerate(files_info, 1):
        ext = os.path.splitext(old_name)[1].lower()
        
        try:
            if file_type == 'image':
                # 图片命名规范：【setutime】-序号
                new_name = f"【setutime】-{img_index}{ext}"
                new_path = os.path.join(target_dir, new_name)
                
                # 如果新文件已存在，先清理
                if os.path.exists(new_path):
                    os.remove(new_path)
                
                # 【优化核心】：直接读取并保存，通过不传递 info 和 exif 丢弃所有元数据，杜绝像素重绘
                with Image.open(old_path) as img:
                    if ext in ['.jpg', '.jpeg']:
                        # quality=95 保持高画质，subsampling=0 防止色彩变淡
                        img.save(new_path, "JPEG", quality=95, subsampling=0, exif=b"")
                    elif ext == '.png':
                        img.save(new_path, "PNG", optimize=False)
                    elif ext == '.webp':
                        img.save(new_path, "WEBP", quality=95)
                    else:
                        img.save(new_path)
                
                # 安全删除原文件
                if old_path != new_path and os.path.exists(old_path):
                    os.remove(old_path)
                img_index += 1
                
            else:
                # 视频命名规范：video-期号-序号
                if ext in ['.mp4', '.mov']:
                    new_name = f"video-{issue_num}-{vid_index}{ext}"
                    new_path = os.path.join(target_dir, new_name)
                    if os.path.exists(new_path):
                        os.remove(new_path)
                    shutil.move(old_path, new_path)
                else:
                    # 非 mp4/mov 视频，强制转码为标准 mp4
                    new_name = f"video-{issue_num}-{vid_index}.mp4"
                    new_path = os.path.join(target_dir, new_name)
                    if os.path.exists(new_path):
                        os.remove(new_path)
                    
                    convert_to_mp4(old_path, new_path)
                    if os.path.exists(old_path):
                        os.remove(old_path)
                vid_index += 1

            success_count += 1
        except Exception:
            # 静默容错或统计，避免打断进度条
            pass
        
        # 更新进度条
        print_progress(i, total)

    # 4. 深度清理子文件夹
    for item in os.listdir(target_dir):
        item_path = os.path.join(target_dir, item)
        if os.path.isdir(item_path):
            try:
                shutil.rmtree(item_path)
            except Exception:
                pass

    print("\n" + "-" * 60)
    print(f" 全部完成！成功处理并提取: {success_count}/{total}")

    # ================= 自动衔接后续水印脚本 =================
    watermark_script = os.path.join(script_dir, "图片加水印.py")
    if os.path.exists(watermark_script):
        input("\n处理已完成，按回车键开始执行 “图片加水印.py”...")
        print("\n正在启动水印脚本...\n")
        try:
            subprocess.run([sys.executable, watermark_script], check=True)
        except Exception as e:
            print(f" 执行水印脚本时出错: {e}")
            input("\n按回车键退出...")
    else:
        print(f"\n 提示：未在同目录找到 “图片加水印.py”")
        input("\n按回车键退出...")

if __name__ == "__main__":
    process_files()