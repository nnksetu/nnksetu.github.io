import os
import shutil

def clear_folders():
    # 1. 已移除 '原视频' 文件夹
    target_folders = [
        '视频输出',
        '水印_压缩后图片',
        '无水印原图'
    ]

    current_dir = os.path.dirname(os.path.abspath(__file__))

    for folder_name in target_folders:
        folder_path = os.path.join(current_dir, folder_name)
        
        # 检查文件夹是否存在，不再打印“跳过”信息以保持终端整洁
        if os.path.exists(folder_path):
            for item in os.listdir(folder_path):
                item_path = os.path.join(folder_path, item)
                try:
                    if os.path.isfile(item_path) or os.path.islink(item_path):
                        os.unlink(item_path)  # 删除文件或快捷方式
                    elif os.path.isdir(item_path):
                        shutil.rmtree(item_path)  # 递归删除子文件夹
                except Exception as e:
                    # 仅在发生错误时进行提示
                    print(f"清理 {folder_name} 时出错: {e}")

if __name__ == "__main__":
    # 直接执行清理，无需输入确认
    clear_folders()
    print("清理完成。")