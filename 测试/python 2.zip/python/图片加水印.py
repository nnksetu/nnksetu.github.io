import os
import shutil
import io
import warnings
import sys
import subprocess
from PIL import Image, ImageDraw, ImageFont

import PIL.Image
PIL.Image.MAX_IMAGE_PIXELS = None
# 忽略 DecompressionBomb 警告
warnings.filterwarnings("ignore", category=Image.DecompressionBombWarning)

def print_progress(current, total, bar_length=40):
    """标准的单行动态进度条"""
    percent = float(current) / total if total > 0 else 1
    arrow = '=' * int(round(percent * bar_length) - 1) + '>'
    spaces = ' ' * (bar_length - len(arrow))
    sys.stdout.write(f"\r水印与压缩进度: [{arrow}{spaces}] {int(percent * 100)}% ({current}/{total})")
    sys.stdout.flush()

def compress_and_watermark_images(
    input_folder="无水印原图",
    output_folder="水印_压缩后图片",
    target_size_mb=2.5,
    max_long_side=5500,
    watermark_text="setutime.com",
    font_path="SourceHanSansCN-Light.otf",
    font_scale=0.02,
    position_type="bottom_left",
    watermark_alpha=90
):
    if os.path.exists(output_folder):
        shutil.rmtree(output_folder)
    os.makedirs(output_folder)

    if not os.path.exists(font_path):
        pass # 静默处理，避免干扰进度条界面

    # 1. 过滤获取有效的待处理图片列表
    valid_exts = ('png', 'jpg', 'jpeg', 'webp', 'bmp', 'tiff')
    all_files = [f for f in os.listdir(input_folder) 
                 if not f.startswith('.') 
                 and not os.path.isdir(os.path.join(input_folder, f)) 
                 and f.lower().endswith(valid_exts)]
    
    total = len(all_files)
    if total == 0:
        print(" 提示：未在输入目录发现可处理的图片。")
    else:
        print("=" * 60)
        print(" 图像水印与压缩引擎 | 正在使用 WebP 编码高速脱敏处理... ")
        print("=" * 60)
        print_progress(0, total)

        processed_count = 0
        target_bytes = target_size_mb * 1024 * 1024

        # 2. 核心流式处理环
        for file_name in all_files:
            input_path = os.path.join(input_folder, file_name)
            
            try:
                with Image.open(input_path) as img:
                    img = img.convert('RGB')
                    original_w, original_h = img.size

                    # 如果超长边超出阈值，等比例缩放
                    if max(original_w, original_h) > max_long_side:
                        scale = max_long_side / max(original_w, original_h)
                        img = img.resize((int(original_w * scale), int(original_h * scale)), Image.LANCZOS)

                    w, h = img.size
                    max_side = max(w, h)

                    # 动态计算字体大小
                    font_size = int(max_side * font_scale)
                    if font_size > w * 0.8:
                        font_size = int(w * 0.2)

                    try:
                        font = ImageFont.truetype(font_path, font_size)
                    except:
                        font = ImageFont.load_default()

                    # 绘制水印
                    draw = ImageDraw.Draw(img, "RGBA")
                    bbox = draw.textbbox((0, 0), watermark_text, font=font)
                    text_w = bbox[2] - bbox[0]
                    text_h = bbox[3] - bbox[1]

                    margin = int(max_side * 0.015)
                    x = margin
                    y = h - text_h - margin - int(text_h * 0.3)
                    if position_type == "bottom_right":
                        x = w - text_w - margin

                    draw.text((x, y), watermark_text, font=font, fill=(255, 255, 255, watermark_alpha))

                    # 3. 内存高效压缩阶梯
                    buf = io.BytesIO()
                    img.save(buf, format='WEBP', quality=88, method=4)
                    size = buf.tell()

                    if size <= target_bytes:
                        final_data = buf.getbuffer()
                    else:
                        quality = 88
                        while quality >= 75:
                            buf = io.BytesIO()
                            img.save(buf, format='WEBP', quality=quality, method=4)
                            size = buf.tell()
                            if size <= target_bytes:
                                final_data = buf.getbuffer()
                                break
                            quality -= 3
                        else:
                            scale = 0.92
                            img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
                            buf = io.BytesIO()
                            img.save(buf, format='WEBP', quality=80, method=4)
                            final_data = buf.getbuffer()

                    # 输出并持久化
                    output_path = os.path.join(output_folder, os.path.splitext(file_name)[0] + '.webp')
                    with open(output_path, "wb") as f:
                        f.write(final_data)

                    processed_count += 1
            except Exception:
                pass

            # 更新单行进度条
            print_progress(processed_count, total)

        print("\n" + "-" * 60)
        print(f" ✨ 全部图片处理完成！共成功处理: {processed_count}/{total}")
        print(f" 输出目录：{output_folder}")

    # ========== 视频文件检测与动态数字菜单 ==========
    script_dir = os.path.dirname(os.path.abspath(__file__))
    video_script = os.path.join(script_dir, "视频压缩.py")
    pack_script = os.path.join(script_dir, "打包.py")
    
    # 依托前置重命名脚本的命名规范，直接检测 "video-" 前缀
    has_video = False
    if os.path.exists(input_folder):
        for f in os.listdir(input_folder):
            if not f.startswith('.') and not os.path.isdir(os.path.join(input_folder, f)):
                if f.lower().startswith('video-'):
                    has_video = True
                    break
    
    print("\n" + "="*30)
    if has_video:
        print(" 📽️ 监测到视频文件，默认操作已切换：")
        print(" [直接回车] : 运行 视频压缩.py")
        print(" 选项 1    : 运行 打包.py")
    else:
        print(" [直接回车] : 运行 打包.py")
        print(" 选项 1    : 运行 视频压缩.py")
    print(" 选项 2    : 退出")
    print("="*30)
    
    try:
        import termios
        termios.tcflush(sys.stdin, termios.TCIFLUSH)
    except Exception:
        pass

    choice = input("请选择下一步操作 (直接回车 或 输入 1/2): ").strip()
    
    # 根据检测结果动态分配脚本执行逻辑
    if has_video:
        default_script, default_name = video_script, "视频压缩.py"
        opt1_script, opt1_name = pack_script, "打包.py"
    else:
        default_script, default_name = pack_script, "打包.py"
        opt1_script, opt1_name = video_script, "视频压缩.py"

    if choice == '':
        if os.path.exists(default_script):
            print(f"正在启动{default_name.split('.')[0]}脚本...\n")
            subprocess.run([sys.executable, default_script])
        else:
            print(f"\n❌ 错误：未在同目录找到 “{default_name}”")
            input("\n按回车键退出...")
            
    elif choice == '1':
        if os.path.exists(opt1_script):
            print(f"正在启动{opt1_name.split('.')[0]}脚本...\n")
            subprocess.run([sys.executable, opt1_script])
        else:
            print(f"\n❌ 错误：未在同目录找到 “{opt1_name}”")
            input("\n按回车键退出...")
            
    elif choice == '2':
        print("已退出。")
        sys.exit(0)
        
    else:
        print("无效的输入，程序退出。")

if __name__ == "__main__":
    compress_and_watermark_images(
        input_folder="无水印原图",
        output_folder="水印_压缩后图片",
        target_size_mb=2.5,
        max_long_side=5500,
        watermark_text="setutime.com",
        font_path="SourceHanSansCN-Light.otf"
    )