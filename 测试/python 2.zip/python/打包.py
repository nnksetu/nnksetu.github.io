import zipfile
import os
import re

CACHE_FILE = '.last_issue.txt'  # 用于记忆期号的缓存文件

def get_issue_number_from_videos(source_folder):
    """从无水印原图文件夹中，智能识别已规范命名的视频期号"""
    if not os.path.exists(source_folder):
        return None
    
    # 匹配规则：video-期号-序号 (例如 video-2026A-1.mp4 提取出 2026A)
    issue_pattern = re.compile(r'^video-([^-]+)-\d+')
    
    for root, dirs, files in os.walk(source_folder):
        for f in files:
            match = issue_pattern.match(f)
            if match:
                return match.group(1)
    return None

def get_remembered_issue():
    """读取上次记录的期号，并尝试自动加 1"""
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                last_val = f.read().strip()
                # 如果是纯数字，自动 +1 智能递增
                if last_val.isdigit():
                    return str(int(last_val) + 1)
                return last_val
        except:
            pass
    return None

def save_issue_number(issue_num):
    """保存本次使用的期号供下次使用"""
    try:
        with open(CACHE_FILE, 'w', encoding='utf-8') as f:
            f.write(str(issue_num))
    except:
        pass

def create_zip():
    # 1. 配置基础路径
    source_folder = '无水印原图'
    readme_file = '说明.txt'
    
    # 检查必要文件/文件夹是否存在
    if not os.path.exists(source_folder):
        print(f"❌ 错误：找不到文件夹 '{source_folder}'")
        input("\n按回车键退出...")
        return
    if not os.path.exists(readme_file):
        print(f"❌ 错误：找不到文件 '{readme_file}'")
        input("\n按回车键退出...")
        return

    # 2. 交互：选择压缩模式
    print("模式选择：")
    print("👉 [直接回车] : 自动压缩（默认模式）")
    print("👉 [输入 1 ]  : 生成伪装后缀（无水印压缩.删除我zip）")
    mode_choice = input("请输入选择并回车: ").strip()

    # 根据选择决定第一层压缩包的名字
    if mode_choice == "1":
        first_zip_name = '无水印压缩.删除我zip'
        print("ℹ️ 已开启伪装模式：第一层压缩包将命名为 '无水印压缩.删除我zip'")
    else:
        first_zip_name = '无水印原图.zip'
        print("ℹ️ 已开启默认模式：第一层压缩包将命名为 '无水印原图.zip'")

    print("-" * 30)

    # 3. 智能期号识别与记忆功能
    issue_num = get_issue_number_from_videos(source_folder)
    
    if issue_num:
        print(f"🤖 智能识别：检测到视频命名规范，自动提取期号为 【{issue_num}】")
        # 识别到规范命名也同步更新一下记忆
        save_issue_number(issue_num)
    else:
        # 获取记忆递增后的期号
        next_issue = get_remembered_issue()
        
        if next_issue:
            print(f" Let's Go! 上次生成的后续期号推荐为: 【{next_issue}】")
            print("👉 [直接回车] : 接受推荐，使用期号 " + next_issue)
            print("👉 [输入 1 ]  : 重新自定义期号")
            user_input = input("请选择并回车: ").strip()
            
            if user_input == '1':
                # 自定义期号分支
                issue_num = input("请输入自定义期数序号（例如 100）: ").strip()
                while not issue_num:
                    issue_num = input("期数不能为空，请重新输入: ").strip()
            else:
                # 默认回车分支
                issue_num = next_issue
        else:
            # 首次运行或者无缓存文件时，降级为全新手动输入
            issue_num = input("请输入期数序号（例如 100）: ").strip()
            while not issue_num:
                issue_num = input("期数不能为空，请重新输入: ").strip()
        
        # 确认最终期号后，将其存入缓存文件
        save_issue_number(issue_num)
            
    second_zip_name = f"ZrSetuTime - 第{issue_num}期原图.zip"

    try:
        # --- 第一次打包：打包“无水印原图”文件夹内的所有文件 ---
        print(f"正在处理图片内容...")
        with zipfile.ZipFile(first_zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(source_folder):
                for file in files:
                    file_path = os.path.join(root, file)
                    # 将文件直接放入压缩包根目录
                    arcname = os.path.relpath(file_path, source_folder)
                    zipf.write(file_path, arcname)

        # --- 第二次打包：打包“说明.txt”和伪装/普通压缩包 ---
        print(f"正在生成最终发布包：{second_zip_name}...")
        with zipfile.ZipFile(second_zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # 添加第一次生成的压缩包（保持原文件名放入大包内）
            zipf.write(first_zip_name, first_zip_name)
            # 添加说明文件
            zipf.write(readme_file, readme_file)

        # --- 静默删除中间文件 ---
        if os.path.exists(first_zip_name):
            os.remove(first_zip_name)
        
        print(f"✨ 最终压缩包打包成功！已生成: {second_zip_name}")
        input("\n任务已全部完成！按回车退出...")

    except Exception as e:
        print(f"❌ 程序运行出错: {e}")
        # 发生错误时如果残留了中间文件，也尝试清理
        if os.path.exists(first_zip_name):
            os.remove(first_zip_name)
        input("\n按回车键退出...")

if __name__ == "__main__":
    create_zip()