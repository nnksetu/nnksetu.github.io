import os
import re
import time
import requests
import pyperclip
from concurrent.futures import ThreadPoolExecutor

# 导入 Rich 相关组件
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeRemainingColumn
from rich.panel import Panel
from rich.text import Text

# 初始化 Rich 控制台
console = Console()

# ----------------- 配置区 -----------------
# 1. 你的 API Key
MY_API_KEY = "chv_aVPY_a78a624355f2ba8f983ed27ae95690a2c00ca2c05ebba7adb1726efebe501adfea0baaf8fb81228866a56decd14e8f231c16d4ac1f7d01b621f4372737f49747" 

# 2. 填写你要上传的文件夹路径
MY_FOLDER_PATH = "/Users/yu7our/python/水印_压缩后图片"

# 3. 10 并发线程数
MAX_WORKERS = 10 
# ------------------------------------------

def natural_sort_key(s):
    """
    自然排序算法的 Key 函数：将字符串中的数字和非数字分开
    例如: "pic-1-2.webp" -> ['pic-', 1, '-', 2, '.webp']
    这样排序时就能保证 2 排在 10 前面
    """
    return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', s)]

def upload_single_image_with_retry(image_path, api_key, max_retries=3):
    """
    单张图片上传函数（包含最多3次原地重试机制）
    """
    url = "https://pic.moebox.io/api/1/upload"
    headers = {"X-API-Key": api_key}
    data = {"format": "txt"}
    file_name = os.path.basename(image_path)
    
    for attempt in range(1, max_retries + 1):
        try:
            with open(image_path, "rb") as file_data:
                files = {"source": file_data}
                response = requests.post(url, headers=headers, data=data, files=files, timeout=30)
                if response.status_code == 200:
                    return image_path, response.text.strip(), True
                else:
                    err_msg = f"HTTP {response.status_code}"
        except Exception as e:
            err_msg = str(e)
            
        # 如果失败，等待 1 秒后重试（最后一次尝试失败则不等待直接返回）
        if attempt < max_retries:
            time.sleep(1)
            
    # 3次都失败了
    return image_path, f"重试{max_retries}次皆失败: {err_msg}", False

def upload_folder_fast_ordered(folder_path, api_key, max_workers=10):
    """
    10线程并发上传整个文件夹，严格按照自然文件名顺序上传和返回
    """
    # 1. 安全检查
    if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
        console.print(Panel(f"[red]❌ 错误:[/red]\n路径不存在或不是文件夹\n[cyan]{folder_path}[/cyan]", title="状态", border_style="red"))
        return

    valid_extensions = ('.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp')
    
    # 获取文件并使用自然排序
    raw_files = [f for f in os.listdir(folder_path) if f.lower().endswith(valid_extensions)]
    raw_files.sort(key=natural_sort_key) # 关键：使用自然排序，保证 1, 2, 3... 10 的物理顺序
    
    image_files = [os.path.join(folder_path, f) for f in raw_files]
            
    if not image_files:
        console.print(Panel(f"📁 文件夹中没有找到图片。\n支持格式: {', '.join(valid_extensions)}", title="扫描结果", border_style="yellow"))
        return

    # 2. 打印准备就绪面板
    start_msg = Text.assemble(
        ("Found ", "cyan"), 
        (f"{len(image_files)}", "magenta bold"), 
        (" images in natural order.\nStarting [bold green]10-Thread[/bold green] upload with up to ", "cyan"),
        ("3 retries", "yellow bold"),
        (" per failure...", "cyan")
    )
    console.print(Panel(start_msg, subtitle="[gray]Order-Guaranteed Mode[/gray]", border_style="cyan"))

    uploaded_links = []
    failed_images = []

    # 3. 渲染精致的进度条
    with Progress(
        SpinnerColumn("earth" if os.name != 'nt' else "dots", speed=1.5),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(bar_width=40, complete_style="green", finished_style="blue"),
        TaskProgressColumn(),
        TextColumn("[gray]ETA:[/gray]"),
        TimeRemainingColumn(),
        console=console,
        transient=True
    ) as progress:

        # 添加总进度条
        total_task = progress.add_task("[bold cyan]Total Progress[/bold cyan]", total=len(image_files))

        # 4. 开启线程池
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # 按严格排序后的顺序提交任务，并将 Future 对象放入一个“有序列表”中
            futures_list = [
                executor.submit(upload_single_image_with_retry, img, api_key) 
                for img in image_files
            ]

            # 5. 关键：按提交任务的【原始顺序】依次等待和处理结果
            for future in futures_list:
                img_path, result, success = future.result() # 阻塞等待，直到当前序号的文件上传（或重试失败）完成
                file_name = os.path.basename(img_path)
                
                short_name = (file_name[:18] + '..') if len(file_name) > 20 else file_name

                if success:
                    uploaded_links.append(result)
                    progress.update(total_task, advance=1, description=f"[green]✓ [有序上传] [magenta]{short_name}[/magenta][/green]")
                else:
                    failed_images.append((file_name, result))
                    # 失败的图片由于跳过了，我们在结果列表中用空位或提示占位，确保整体行数和顺序不乱（或者不添加，这里不添加代表直接剔除失败项）
                    progress.update(total_task, advance=1, description=f"[red]✗ Failed: [magenta]{short_name}[/magenta][/red]")

    # 6. 上传结束，打印汇总面板
    console.print("\n" + "—"*55 + "\n")

    if uploaded_links:
        report_text = Text()
        report_text.append("⚡ [bold green]All uploads finished in perfect order![/bold green]\n\n")
        report_text.append(f" ✅ Success (Ordered): ", style="cyan")
        report_text.append(f"{len(uploaded_links)} / {len(image_files)} pics\n", style="magenta bold")
        
        if failed_images:
            report_text.append(f" ❌ Failed:            ", style="red")
            report_text.append(f"{len(failed_images)} pics\n", style="red bold")
            report_text.append("\n[yellow]Failed List:[/yellow]\n")
            for name, err in failed_images:
                report_text.append(f"  • {name} -> [red]{err}[/red]\n")

        console.print(Panel(report_text, title="[bold green]Upload Summary[/bold green]", border_style="green", expand=False))
        
        # 7. 回车确认机制
        print("\n")
        input("👉 请按 [回车键 (Enter)] 确认将所有排序好的图片链接拷贝到剪贴板...")
        
        # 用户按下回车后开始拷贝
        links_text = "\n".join(uploaded_links)
        pyperclip.copy(links_text)
        
        console.print("\n[bold green]📋 完美！所有链接已按 1,2,3... 顺序复制到剪贴板！可以直接去粘贴了。[/bold green]")
    else:
        console.print(Panel("[bold red]⚠️ No images were uploaded successfully.[/bold red]", title="Error Report", border_style="red"))

if __name__ == "__main__":
    upload_folder_fast_ordered(MY_FOLDER_PATH, MY_API_KEY, max_workers=MAX_WORKERS)