import subprocess
import os
import sys
import re

def get_script_directory():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def natural_sort_key(filename):
    def convert(text):
        return int(text) if text.isdigit() else text.lower()
    def alphanum_key(key):
        return [convert(c) for c in re.split('([0-9]+)', key)]
    return alphanum_key(filename)

def print_progress(current, total, bar_length=40):
    percent = float(current) / total
    arrow = '=' * int(round(percent * bar_length) - 1) + '>'
    spaces = ' ' * (bar_length - len(arrow))
    sys.stdout.write(f"\r视频水印与压缩进度: [{arrow}{spaces}] {int(percent * 100)}% ({current}/{total})")
    sys.stdout.flush()

def convert_to_mp4(input_file, temp_mp4_path):
    command = [
        'ffmpeg', '-y', '-i', input_file,
        '-vcodec', 'libx264', '-acodec', 'aac',
        '-loglevel', 'error'
    ]
    command.append(temp_mp4_path)
    subprocess.run(command, check=True)

def compress_and_watermark(input_file, output_file, watermark_text="setutime.com", qq_text="qq：51301105", crf=20, 
                          font_file='SourceHanSansCN-Light.otf',
                          watermark_height_ratio=0.03):
    
    fontsize_expr = f"h*{watermark_height_ratio}"
    
    vf_chain = [
        "scale='min(1920,iw)':'min(1080,ih)':force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2",
        f"drawtext=fontfile='{font_file}':text='{watermark_text}':"
        f"fontsize={fontsize_expr}:fontcolor=white@0.85:borderw=1:bordercolor=black@0.6:"
        "x=10:y=main_h-text_h-10",
        f"drawtext=fontfile='{font_file}':text='{qq_text}':"
        f"fontsize={fontsize_expr}:fontcolor=white@0.85:borderw=1:bordercolor=black@0.6:"
        "x=main_w-text_w-10:y=10"
    ]
    
    command = [
        'ffmpeg', '-y', '-i', input_file,
        '-vf', ",".join(vf_chain),
        '-vcodec', 'libx264', '-crf', str(crf),
        '-preset', 'medium', '-acodec', 'aac',
        '-loglevel', 'error'
    ]
    command.append(output_file)
    
    subprocess.run(command, check=True)

if __name__ == "__main__":
    script_dir = get_script_directory()
    
    input_dir = os.path.join(script_dir, '视频在线')
    output_dir = os.path.join(script_dir, '视频输出')
    font_path = os.path.join(script_dir, 'SourceHanSansCN-Light.otf')
    
    print("=" * 60)
    print(" 视频水印与高压缩比引擎 | 正在启动流式转码... ")
    print("=" * 60)
    
    if not os.path.exists(font_path):
        print(f"❌ 错误：未在同目录下找到字体文件 {font_path}")
        sys.exit(1)
    
    if not os.path.exists(input_dir):
        print(f"❌ 错误：未找到输入目录 {input_dir}")
        sys.exit(1)
        
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    video_extensions = ('.mp4', '.mov', '.avi', '.flv', '.mkv', '.wmv', '.m4v', '.webm', '.ts')
    video_tasks = []
    
    if os.path.exists(input_dir):
        for f in os.listdir(input_dir):
            if f.lower().endswith(video_extensions) and os.path.isfile(os.path.join(input_dir, f)):
                video_tasks.append(f)
                
    total = len(video_tasks)
    if total == 0:
        print(" 提示：在 '/视频在线' 根目录中未找到任何待压缩的视频文件。")
        sys.exit(0)
        
    video_tasks.sort(key=natural_sort_key)

    print(f" 📦 发现 {total} 个视频文件，正在直接全自动执行视频水印与压缩...")
    print_progress(0, total)
    
    success_count = 0

    for index, filename in enumerate(video_tasks, start=1):
        old_path = os.path.join(input_dir, filename)
        
        name_without_ext, ext = os.path.splitext(filename)
        ext_lower = ext.lower()
        
        if ext_lower in ('.mp4', '.mov'):
            final_output_path = os.path.join(output_dir, name_without_ext + ext_lower)
            source_to_compress = old_path
            temp_file_to_clean = None
        else:
            final_output_path = os.path.join(output_dir, name_without_ext + '.mp4')
            temp_mp4_path = os.path.join(input_dir, f"temp_{name_without_ext}.mp4")
            source_to_compress = temp_mp4_path
            temp_file_to_clean = temp_mp4_path
        
        try:
            if os.path.exists(final_output_path):
                os.remove(final_output_path)
                
            if temp_file_to_clean:
                convert_to_mp4(old_path, temp_file_to_clean)
                
            compress_and_watermark(source_to_compress, final_output_path, font_file=font_path)
            success_count += 1
        except Exception:
            pass
        finally:
            if temp_file_to_clean and os.path.exists(temp_file_to_clean):
                try:
                    os.remove(temp_file_to_clean)
                except Exception:
                    pass
            
        print_progress(index, total)

    print("\n" + "-" * 60)
    print(f" ✨ 全部视频处理完成！共成功压缩: {success_count}/{total}")
    print(f" 压缩后的视频已保存在: {output_dir}")