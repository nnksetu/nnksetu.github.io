import subprocess
import os
import sys
import re

def get_script_directory():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def natural_sort_key(filename):
    """自然排序逻辑，确保 video-1, video-2 顺序准确"""
    def convert(text):
        return int(text) if text.isdigit() else text.lower()
    def alphanum_key(key):
        return [convert(c) for c in re.split('([0-9]+)', key)]
    return alphanum_key(filename)

def print_progress(current, total, bar_length=40):
    """标准的单行动态进度条"""
    percent = float(current) / total
    arrow = '=' * int(round(percent * bar_length) - 1) + '>'
    spaces = ' ' * (bar_length - len(arrow))
    sys.stdout.write(f"\r视频水印与压缩进度: [{arrow}{spaces}] {int(percent * 100)}% ({current}/{total})")
    sys.stdout.flush()

def compress_and_watermark(input_file, output_file, watermark_text="setutime.com", crf=26, 
                          font_file='SourceHanSansCN-Light.otf',
                          watermark_height_ratio=0.03):
    
    # 水印大小表达式
    fontsize_expr = f"h*{watermark_height_ratio}"
    
    # 滤镜链：保持比例缩放 + 绘制文字
    vf_chain = [
        "scale='min(1920,iw)':'min(1080,ih)':force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2",
        f"drawtext=fontfile='{font_file}':text='{watermark_text}':"
        f"fontsize={fontsize_expr}:fontcolor=white@0.85:borderw=1:bordercolor=black@0.6:"
        "x=10:y=main_h-text_h-10"
    ]
    
    command = [
        'ffmpeg', '-y', '-i', input_file,
        '-vf', ",".join(vf_chain),
        '-vcodec', 'libx264', '-crf', str(crf),
        '-preset', 'medium', '-acodec', 'aac', # 统一转码音频为兼容性最佳的 aac
        '-loglevel', 'error' # 静默 ffmpeg 刷屏输出，不干扰进度条
    ]
    command.append(output_file)
    
    # 调用底层 FFmpeg 核心
    subprocess.run(command, check=True)

if __name__ == "__main__":
    script_dir = get_script_directory()
    
    # 定义输入输出目录
    input_dir = os.path.join(script_dir, '无水印原图')
    output_dir = os.path.join(script_dir, '视频输出')
    font_path = os.path.join(script_dir, 'SourceHanSansCN-Light.otf')
    
    print("=" * 60)
    print(" 视频水印与高压缩比引擎 | 正在启动流式转码... ")
    print("=" * 60)
    
    # 环境自检
    if not os.path.exists(font_path):
        print(f"❌ 错误：未在同目录下找到字体文件 {font_path}")
        sys.exit(1)
    
    if not os.path.exists(input_dir):
        print(f"❌ 错误：未找到输入目录 {input_dir}")
        sys.exit(1)
        
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # 1. 仅检索根目录下已被第一个脚本规范命名的视频文件
    video_tasks = []
    if os.path.exists(input_dir):
        for f in os.listdir(input_dir):
            if f.lower().startswith('video-') and os.path.isfile(os.path.join(input_dir, f)):
                video_tasks.append(f)
                
    total = len(video_tasks)
    if total == 0:
        print(" 提示：在 '/无水印原图' 根目录中未找到任何待压缩的视频文件。")
        sys.exit(0)
        
    # 按自然顺序排列任务
    video_tasks.sort(key=natural_sort_key)

    print(f" 📦 发现 {total} 个已规范命名的视频，正在直接全自动执行视频水印与压缩...")
    print_progress(0, total)
    
    success_count = 0

    # 3. 核心压缩循环
    for index, filename in enumerate(video_tasks, start=1):
        old_path = os.path.join(input_dir, filename)
        final_output_path = os.path.join(output_dir, filename)
        
        try:
            # 如果已有残存的同名输出文件，先将其删除
            if os.path.exists(final_output_path):
                os.remove(final_output_path)
                
            # 直接调用 FFmpeg 进行加水印与高比例压缩
            compress_and_watermark(old_path, final_output_path, font_file=font_path)
            success_count += 1
        except Exception:
            # 容错：个别转码失败时静默跳过，确保进度条连贯不卡死
            pass
            
        # 更新单行进度条
        print_progress(index, total)

    print("\n" + "-" * 60)
    print(f" ✨ 全部视频处理完成！共成功压缩: {success_count}/{total}")
    print(f" 压缩后的视频已保存在: {output_dir}")

    # ========== 链式执行：按回车自动启动打包脚本 ==========
    pack_script = os.path.join(script_dir, "打包.py")
    if os.path.exists(pack_script):
        input("\n 视频处理已完成，按【回车键】开始启动 “打包.py”...")
        print("正在启动打包脚本...\n")
        subprocess.run([sys.executable, pack_script])
    else:
        print(f"\n提示：未在同目录找到 “打包.py”")