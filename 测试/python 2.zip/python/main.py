import os
import re
import sys
import io
import json
import glob
import shutil
import warnings
import zipfile
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from PIL import Image, ImageDraw, ImageFont

if sys.platform != 'win32':
    import select
    import termios  # macOS/Linux 用于精准控制终端缓存

import PIL.Image
PIL.Image.MAX_IMAGE_PIXELS = None
warnings.filterwarnings("ignore", category=Image.DecompressionBombWarning)

# ==================== 全局状态 ====================
GLOBAL_ISSUE_NUM = ""  # 全局统一本期期号
IS_MANUAL_MODE = False  # 标记当前是否为手动模式
SELECTED_NAMING_TYPE = 1  # 记录用户最终选择的命名方式 (1: zrsetu, 2: setu, 3: acg)

# ==================== 全局通用工具 ====================

def get_script_directory():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def natural_sort_key(file_info):
    filename = file_info[1]
    def convert(text):
        return int(text) if text.isdigit() else text.lower()
    def alphanum_key(key):
        return [convert(c) for c in re.split('([0-9]+)', key)]
    return alphanum_key(filename)

def print_progress(current, total, prefix="处理进度", bar_length=30):
    percent = float(current) / total if total > 0 else 1
    arrow = '=' * int(round(percent * bar_length) - 1) + '>'
    spaces = ' ' * (bar_length - len(arrow))
    sys.stdout.write(f"\r{prefix}: [{arrow}{spaces}] {int(percent * 100)}% ({current}/{total})")
    sys.stdout.flush()

def load_issue_config():
    """读取包含三种命名变量的配置文件 .last_issue"""
    script_dir = get_script_directory()
    config_file = os.path.join(script_dir, ".last_issue")
    default_config = {"type1": 1, "type2": 1, "type3": 1}
    
    if os.path.exists(config_file):
        try:
            with open(config_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            try:
                with open(config_file, "r", encoding="utf-8") as f:
                    match = re.search(r'\d+', f.read().strip())
                    if match:
                        val = int(match.group())
                        return {"type1": val, "type2": val, "type3": val}
            except:
                pass
    return default_config

def ensure_global_issue_num():
    """展示三种线路的建议期号，并根据输入智能判定选用哪条线路以及期号"""
    global GLOBAL_ISSUE_NUM, SELECTED_NAMING_TYPE
    if GLOBAL_ISSUE_NUM:
        return

    config = load_issue_config()
    next_t1 = config.get("type1", 0) + 1
    next_t2 = config.get("type2", 0) + 1
    next_t3 = config.get("type3", 0) + 1
    
    print("\n💡 管道运行需要期号！当前各线路推荐期号如下:")
    print(f" 💎 [直接回车] 专属类 (zrsetu) ➡️ 建议值: {next_t1}")
    print(f" 🌿 [输入 2]   纯净类 (setu)   ➡️ 建议值: {next_t2}")
    print(f" 🎨 [输入 3]   ACG类  (acg)    ➡️ 建议值: {next_t3}")
    print(" ✍️ [手动输入] 若需要其他特定期号，请直接输入具体数字 (如: 715)")
    
    user_input = silent_timeout_input("\n👉 请选择线路或输入期号 (⏳ 15秒无输入默认专属类): ", timeout=15, default="").strip()
    
    if user_input == "" or user_input == "1":
        SELECTED_NAMING_TYPE = 1
        GLOBAL_ISSUE_NUM = str(next_t1)
    elif user_input == "2":
        SELECTED_NAMING_TYPE = 2
        GLOBAL_ISSUE_NUM = str(next_t2)
    elif user_input == "3":
        SELECTED_NAMING_TYPE = 3
        GLOBAL_ISSUE_NUM = str(next_t3)
    elif user_input.isdigit():
        # 用户输入了纯数字，默认当作专属类期号处理
        GLOBAL_ISSUE_NUM = user_input
        SELECTED_NAMING_TYPE = 1
        print(f"ℹ️ 检测到手动输入特定期号，默认绑定至专属类(zrsetu)配置。")
    else:
        # 其他兜底情况
        SELECTED_NAMING_TYPE = 1
        GLOBAL_ISSUE_NUM = str(next_t1)

    line_names = {1: "专属类 (zrsetu)", 2: "纯净类 (setu)", 3: "ACG类 (acg)"}
    print(f"✅ 成功锁定线路: {line_names[SELECTED_NAMING_TYPE]} | 本期期号设定为: \033[1;32m{GLOBAL_ISSUE_NUM}\033[0m")

def save_issue_cache():
    """打包成功后，使当前选中的命名变量自动+1并持久化"""
    global GLOBAL_ISSUE_NUM, SELECTED_NAMING_TYPE
    if not GLOBAL_ISSUE_NUM:
        return
    try:
        script_dir = get_script_directory()
        config_file = os.path.join(script_dir, ".last_issue")
        config = load_issue_config()
        
        key = f"type{SELECTED_NAMING_TYPE}"
        try:
            config[key] = int(GLOBAL_ISSUE_NUM)
        except:
            config[key] += 1
            
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4, ensure_ascii=False)
        print(f"💾 历史期数缓存已成功更新 (.last_issue) -> 方案 {SELECTED_NAMING_TYPE} 当前记录为: {config[key]}")
    except Exception as e:
        print(f"⚠️ 写入期数缓存失败: {e}")

# ==================== R2 极速上传子系统 ====================

def run_rclone_with_bar(local_dir, remote_path, desc="正在传输"):
    command = [
        "rclone", "copy", local_dir, remote_path,
        "--transfers", "16",
        "--checkers", "16",
        "--progress",
        "--stats", "1s",
        "--no-traverse",
        "--s3-disable-checksum",
        "--ignore-checksum",
        "--contimeout", "10s",
        "--low-level-retries", "3"
    ]
    try:
        from tqdm import tqdm
    except ImportError:
        print(f"ℹ️ 提示：未安装 tqdm 库，将使用 rclone 默认输出。")
        subprocess.run(command)
        return True

    progress_regex = re.compile(r"Transferred:\s+([\d.]+.*?)\s+/\s+([\d.]+.*?),\s+(\d+)%,\s+([\d.]+.*?/s),\s+(ETA\s+.*)")
    percent_regex = re.compile(r"Transferred:.*,\s+(\d+)%")
    
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    pbar = tqdm(total=100, desc=desc, ascii="▱▰", bar_format="\033[1;32m{l_bar}\033[0m\033[1;36m{bar}\033[0m| \033[1;33m{n_fmt}/{total_fmt}%\033[0m {postfix}")
    last_percent = 0
    
    try:
        while True:
            line = process.stdout.readline()
            if not line and process.poll() is not None: break
            if "Transferred:" not in line:
                clean_line = line.strip()
                if clean_line and not clean_line.startswith("*") and len(clean_line) < 50:
                    pbar.set_description(f"{desc} ({clean_line})")
            if "Transferred:" in line:
                current_percent = None
                match = progress_regex.search(line)
                if match:
                    current_percent = int(match.group(3))
                    pbar.set_description(desc)
                    pbar.set_postfix_str(f"[\033[1;35m⚡ {match.group(4)}\033[0m] [\033[1;30m{match.group(5)}\033[0m]")
                else:
                    match_pct = percent_regex.search(line)
                    if match_pct:
                        current_percent = int(match_pct.group(1))
                        pbar.set_description(desc)
                if current_percent is not None and current_percent > last_percent:
                    pbar.update(current_percent - last_percent)
                    last_percent = current_percent
        process.wait()
        pbar.n = 100
        pbar.refresh()
        pbar.close()
        return process.returncode == 0
    except KeyboardInterrupt:
        pbar.close()
        process.terminate()
        return False

def trigger_auto_upload_pipeline():
    """主程序及手动模式通用的联动自动上传流程 (已对齐各自分流渠道)"""
    global SELECTED_NAMING_TYPE, IS_MANUAL_MODE
    print("\n🚀 [自动联动] 正在启动 R2 媒体资产分流上传...")
    script_dir = get_script_directory()
    img_folder = os.path.join(script_dir, "水印_压缩后图片")
    video_folder = os.path.join(script_dir, "视频输出")
    
    target_video = None
    
    # 手动模式下保持自由选择渠道
    if IS_MANUAL_MODE:
        print("\n👉 [手动模式] 请选择 R2 媒体桶分流渠道:")
        print(" [1] 🎯 专属类 —— 图片 ➡️ /zrsetu_pic  &  视频 ➡️ /zrsetu (直接回车默认)")
        print(" [2] 🌿 纯净类 —— 图片 ➡️ /setu_pic    &  视频 ➡️ /setu")
        print(" [3] 🎨 ACG类  —— 图片 ➡️ /acg_pic")
        sub_choice = input("👉 请输入选项 (1/2/3): ").strip()
        if sub_choice == "2":
            target_img, target_video = "r2:setutime/setu_pic/", "r2:setutime/setu/"
        elif sub_choice == "3":
            target_img = "r2:setutime/acg_pic/"
        else:
            target_img, target_video = "r2:setutime/zrsetu_pic/", "r2:setutime/zrsetu/"
    # 自动模式下不需要手动选择，根据最初选定的线路绝对绑定对齐
    else:
        if SELECTED_NAMING_TYPE == 1:
            print("📦 自动识别：已对齐专属渠道 (/zrsetu_pic & /zrsetu)")
            target_img, target_video = "r2:setutime/zrsetu_pic/", "r2:setutime/zrsetu/"
        elif SELECTED_NAMING_TYPE == 2:
            print("📦 自动识别：已对齐纯净渠道 (/setu_pic & /setu)")
            target_img, target_video = "r2:setutime/setu_pic/", "r2:setutime/setu/"
        elif SELECTED_NAMING_TYPE == 3:
            print("📦 自动识别：已对齐ACG渠道 (/acg_pic)")
            target_img = "r2:setutime/acg_pic/"

    # 执行图片上传
    if os.path.exists(img_folder) and os.listdir(img_folder):
        run_rclone_with_bar(img_folder, target_img, desc="🖼️  图片分流上传")
    # 执行视频上传
    if target_video and os.path.exists(video_folder) and os.listdir(video_folder):
        run_rclone_with_bar(video_folder, target_video, desc="🎬 视频分流上传")

    print("\n✅ R2 媒体渠道联动同步流全部顺利完成！(压缩包ZIP已跳过上传)")

# ==================== 核心模块 1: 重命名 ====================

def get_all_files_recursive(directory):
    if not os.path.exists(directory): return [], False, False
    image_exts = ('.jpg', '.jpeg', '.png', '.webp', '.bmp', '.tif', '.tiff')
    video_exts = ('.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm')
    gif_exts = ('.gif', '.GIF')
    all_files = []
    has_video, has_gif = False, False
    for root, dirs, files in os.walk(directory):
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            if ext in gif_exts:
                all_files.append((os.path.join(root, f), os.path.relpath(os.path.join(root, f), directory), f, 'gif'))
                has_gif = True
            elif ext in image_exts:
                all_files.append((os.path.join(root, f), os.path.relpath(os.path.join(root, f), directory), f, 'image'))
            elif ext in video_exts:
                all_files.append((os.path.join(root, f), os.path.relpath(os.path.join(root, f), directory), f, 'video'))
                has_video = True
    all_files.sort(key=natural_sort_key)
    return all_files, has_video, has_gif

def clean_empty_directories(target_dir):
    all_dirs = []
    for root, dirs, files in os.walk(target_dir, topdown=False):
        if root == target_dir or os.path.basename(root) in ['V', 'gif']: continue
        all_dirs.append(root)
    all_dirs.sort(key=lambda x: len(x), reverse=True)
    for folder in all_dirs:
        if not os.path.exists(folder): continue
        if not [f for f in os.listdir(folder) if not f.startswith('.')]:
            try:
                for f in os.listdir(folder): os.remove(os.path.join(folder, f))
                os.rmdir(folder)
            except: pass

def convert_to_mp4(input_path, output_path):
    cmd = ['ffmpeg', '-y', '-i', input_path, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-loglevel', 'error']
    subprocess.run(cmd, check=True)

def module_rename():
    global GLOBAL_ISSUE_NUM
    ensure_global_issue_num()
    print("\n🚀 步骤 1: 规范化重命名与脱敏")
    script_dir = get_script_directory()
    target_dir = os.path.join(script_dir, "无水印原图")
    if not os.path.exists(target_dir):
        print(f"❌ 错误：找不到文件夹 '{target_dir}'")
        return False
    files_info, has_video, has_gif = get_all_files_recursive(target_dir)
    total = len(files_info)
    if total == 0: return False

    video_dir, gif_dir = os.path.join(target_dir, "V"), os.path.join(target_dir, "gif")
    print_progress(0, total, "准备过渡中")
    temp_files_info = []
    for i, (old_path, rel_path, old_name, file_type) in enumerate(files_info, 1):
        if not os.path.exists(old_path): continue
        ext = os.path.splitext(old_name)[1].lower()
        temp_path = os.path.join(os.path.dirname(old_path), f"temp_process_{i}_{time.time_ns()}{ext}")
        try:
            shutil.move(old_path, temp_path)
            temp_files_info.append((temp_path, old_name, file_type))
        except Exception as e: print(f"\n❌ 建立临时文件失败: {e}")

    img_index, vid_index, gif_index, success_count = 1, 1, 1, 0
    for i, (temp_path, old_name, file_type) in enumerate(temp_files_info, 1):
        ext = os.path.splitext(old_name)[1].lower()
        try:
            if file_type == 'image':
                new_path = os.path.join(target_dir, f"【setutime】-{img_index}{ext}")
                if os.path.exists(new_path): os.remove(new_path)
                with Image.open(temp_path) as img:
                    if ext in ['.jpg', '.jpeg']: img.save(new_path, "JPEG", quality=95, subsampling=0, exif=b"")
                    elif ext == '.png': img.save(new_path, "PNG", optimize=False)
                    else: img.save(new_path)
                if os.path.exists(temp_path): os.remove(temp_path)
                img_index += 1
            elif file_type == 'gif':
                os.makedirs(gif_dir, exist_ok=True)
                new_path = os.path.join(gif_dir, f"gif-{GLOBAL_ISSUE_NUM}-{gif_index}.gif")
                if os.path.exists(new_path): os.remove(new_path)
                os.rename(temp_path, new_path)
                gif_index += 1
            elif file_type == 'video':
                os.makedirs(video_dir, exist_ok=True)
                new_path = os.path.join(video_dir, f"video-{GLOBAL_ISSUE_NUM}-{vid_index}" + (".mp4" if ext not in ['.mp4', '.mov'] else ext))
                if os.path.exists(new_path): os.remove(new_path)
                if ext in ['.mp4', '.mov']: shutil.move(temp_path, new_path)
                else:
                    convert_to_mp4(temp_path, new_path)
                    if os.path.exists(temp_path): os.remove(temp_path)
                vid_index += 1
            success_count += 1
        except Exception as e: print(f"\n❌ 落盘失败: {e}")
        print_progress(i, total, "重命名中")
    clean_empty_directories(target_dir)
    print(f"\n✨ 重命名与分类完成: {success_count}/{total}")
    return True

# ==================== 核心模块 2: 图片加水印 ====================

def process_single_image(file_name, idx, issue_num, input_folder, output_folder, target_bytes, max_long_side, base_width, watermark_text, font_path, font_scale, watermark_alpha):
    input_path = os.path.join(input_folder, file_name)
    try:
        buf = io.BytesIO()
        with Image.open(input_path) as img:
            img = img.convert('RGB')
            w, h = img.size
            if max(w, h) > max_long_side:
                scale = max_long_side / max(w, h)
                img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
                w, h = img.size
            font_size = max(12, int(w * font_scale))
            try: font = ImageFont.truetype(font_path, font_size)
            except: font = ImageFont.load_default()
            draw = ImageDraw.Draw(img, "RGBA")
            bbox = draw.textbbox((0, 0), watermark_text, font=font)
            text_w, text_h = bbox[2] - bbox[0], bbox[3] - bbox[1]
            margin = int(w * 0.02)
            draw.text((margin, h - text_h - margin - int(text_h * 0.3)), watermark_text, font=font, fill=(255, 255, 255, watermark_alpha))
            img.save(buf, format='WEBP', quality=88, method=3)
            final_data = buf.getbuffer() if buf.tell() <= target_bytes else None
            if not final_data:
                quality = 85
                while quality >= 75:
                    buf.seek(0); buf.truncate(0)
                    img.save(buf, format='WEBP', quality=quality, method=3)
                    if buf.tell() <= target_bytes:
                        final_data = buf.getbuffer(); break
                    quality -= 3
            if not final_data:
                img = img.resize((int(w * 0.92), int(h * 0.92)), Image.LANCZOS)
                buf.seek(0); buf.truncate(0)
                img.save(buf, format='WEBP', quality=80, method=3)
                final_data = buf.getbuffer()
            with open(os.path.join(output_folder, f"pic-{issue_num}-{idx}.webp"), "wb") as f: f.write(final_data)
            return True
    except: return False

def module_watermark():
    global GLOBAL_ISSUE_NUM
    ensure_global_issue_num()
    print("\n🎨 步骤 2: 图片加水印与压缩 (M5 多线程加速)")
    input_folder, output_folder = "无水印原图", "水印_压缩后图片"
    if os.path.exists(output_folder): shutil.rmtree(output_folder)
    os.makedirs(output_folder)
    if not os.path.exists(input_folder): return False
    all_files = [f for f in os.listdir(input_folder) if not f.startswith('.') and not os.path.isdir(os.path.join(input_folder, f)) and f.lower().endswith(('png', 'jpg', 'jpeg', 'webp', 'bmp', 'tiff'))]
    all_files.sort(key=lambda x: [int(c) if c.isdigit() else c.lower() for c in re.split('([0-9]+)', x)])
    total = len(all_files)
    if total == 0: return True
    processed_count = 0
    print_progress(0, total, "图片水印")
    with ThreadPoolExecutor(max_workers=min(16, os.cpu_count() * 2)) as executor:
        futures = {executor.submit(process_single_image, f, idx, GLOBAL_ISSUE_NUM, input_folder, output_folder, 2.5*1024*1024, 5500, 3000, "setutime.com", "SourceHanSansCN-Light.otf", 0.028, 90): f for idx, f in enumerate(all_files, 1)}
        for future in as_completed(futures):
            if future.result(): processed_count += 1
            print_progress(processed_count, total, "图片水印")
    print(f"\n✨ 图片处理完成: {processed_count}/{total}")
    return True

# ==================== 核心模块 3: 视频压缩 ====================

def compress_and_watermark_video_worker(old_path, final_output_path, font_path, watermark_text, crf, watermark_height_ratio):
    try:
        vf_chain = [f"scale='min(1920,iw)':'min(1080,ih)':force_original_aspect_ratio=decrease,pad=ceil(iw/2)*2:ceil(ih/2)*2", f"drawtext=fontfile='{font_path}':text='{watermark_text}':fontsize=h*{watermark_height_ratio}:fontcolor=white@0.85:borderw=1:bordercolor=black@0.6:x=10:y=main_h-text_h-10"]
        subprocess.run(['ffmpeg', '-y', '-i', old_path, '-vf', ",".join(vf_chain), '-vcodec', 'libx264', '-crf', str(crf), '-preset', 'medium', '-acodec', 'aac', '-f', 'mp4', '-loglevel', 'error', final_output_path], check=True)
        return True
    except: return False

def module_video():
    print("\n🎬 步骤 3: 视频加水印与转码压缩")
    script_dir = get_script_directory()
    input_dir, output_dir, font_path = os.path.join(script_dir, '无水印原图', 'V'), os.path.join(script_dir, '视频输出'), os.path.join(script_dir, 'SourceHanSansCN-Light.otf')
    if not os.path.exists(font_path) or not os.path.exists(input_dir): return False
    if not os.path.exists(output_dir): os.makedirs(output_dir)
    video_tasks = [f for f in os.listdir(input_dir) if f.lower().startswith('video-') and os.path.isfile(os.path.join(input_dir, f))]
    total = len(video_tasks)
    if total == 0: return False
    video_tasks.sort(key=natural_sort_key)
    print_progress(0, total, "视频转码")
    success_count = 0
    with ProcessPoolExecutor(max_workers=min(2, os.cpu_count())) as executor:
        futures = {}
        for filename in video_tasks:
            out_p = os.path.join(output_dir, os.path.splitext(filename)[0] + ".mp4")
            if os.path.exists(out_p): os.remove(out_p)
            futures[executor.submit(compress_and_watermark_video_worker, os.path.join(input_dir, filename), out_p, font_path, "setutime.com", 26, 0.03)] = filename
        for future in as_completed(futures):
            if future.result(): success_count += 1
            print_progress(success_count, total, "视频转码")
    print(f"\n✨ 视频压缩完成: {success_count}/{total}")
    return True

# ==================== 核心模块 4: 打包 (精准对齐所选线路) ====================

def module_pack():
    global GLOBAL_ISSUE_NUM, IS_MANUAL_MODE, SELECTED_NAMING_TYPE
    ensure_global_issue_num()
    
    print("\n📦 步骤 4: 自动配置归类与打包")
    source_folder, readme_file = '无水印原图', '说明.txt'
    if not os.path.exists(source_folder) or not os.path.exists(readme_file):
        print(f"❌ 错误：缺少 '{source_folder}' 或 '{readme_file}'，无法打包。")
        return False

    config = load_issue_config()

    print("\n✨ 请确认压缩包命名方式 (⏳ 15秒无输入自动应用最初选择的线路):")
    m1 = "★ " if SELECTED_NAMING_TYPE == 1 else ""
    m2 = "★ " if SELECTED_NAMING_TYPE == 2 else ""
    m3 = "★ " if SELECTED_NAMING_TYPE == 3 else ""
    print(f" [1] {m1}💎 第一种：ZrSetuTime - 第{GLOBAL_ISSUE_NUM}期原图.zip  (当前记录: {config['type1']})")
    print(f" [2] {m2}📂 第二种：SetuTime - 第{GLOBAL_ISSUE_NUM}期原图.zip    (当前记录: {config['type2']})")
    print(f" [3] {m3}🎨 第三种：SetuTime精选美图 - {GLOBAL_ISSUE_NUM}.zip     (当前记录: {config['type3']})")
    
    naming_choice = silent_timeout_input(f"👉 请输入选择 (直接回车默认方案 {SELECTED_NAMING_TYPE}): ", timeout=15, default="").strip()
    
    if naming_choice == "1":
        SELECTED_NAMING_TYPE = 1
    elif naming_choice == "2":
        SELECTED_NAMING_TYPE = 2
    elif naming_choice == "3":
        SELECTED_NAMING_TYPE = 3

    if SELECTED_NAMING_TYPE == 2:
        second_zip_name = f"SetuTime - 第{GLOBAL_ISSUE_NUM}期原图.zip"
    elif SELECTED_NAMING_TYPE == 3:
        second_zip_name = f"SetuTime精选美图 - {GLOBAL_ISSUE_NUM}.zip"
    else:
        second_zip_name = f"ZrSetuTime - 第{GLOBAL_ISSUE_NUM}期原图.zip"

    mode_choice = silent_timeout_input("📦 伪装包策略 [回车]:普通原图包 [1]:高级伪装包: ", timeout=5, default="")
    first_zip_name = '无水印原图.删除我zip' if mode_choice == "1" else '无水印原图.zip'

    try:
        with zipfile.ZipFile(first_zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(source_folder):
                for file in files:
                    file_path = os.path.join(root, file)
                    zipf.write(file_path, os.path.relpath(file_path, source_folder))

        with zipfile.ZipFile(second_zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
            zipf.write(first_zip_name, arcname=os.path.basename(first_zip_name))
            zipf.write(readme_file, arcname=os.path.basename(readme_file))

        if os.path.exists(first_zip_name): os.remove(first_zip_name)
        print(f"✨ 最终目标压缩包本地生成成功: \033[1;32m{second_zip_name}\033[0m")
        
        save_issue_cache()
        
        # 手动模式如果单独打包，打包结束后立即在这里触发 R2 上传
        if IS_MANUAL_MODE:
            trigger_auto_upload_pipeline()
            
        return True
    except Exception as e:
        print(f"❌ 打包失败: {e}")
        if os.path.exists(first_zip_name): os.remove(first_zip_name)
        return False

# ==================== 跨平台倒计时核心逻辑 ====================

def silent_timeout_input(prompt, timeout=15, default=""):
    print(prompt, end="", flush=True)
    if sys.platform == 'win32':
        import msvcrt
        while msvcrt.kbhit(): msvcrt.getch()
    else:
        try: termios.tcflush(sys.stdin, termios.TCIFLUSH)
        except: sys.stdin.flush()
    user_input = [default]
    if sys.platform != 'win32':
        ready, _, _ = select.select([sys.stdin], [], [], timeout)
        if ready: user_input[0] = sys.stdin.readline().rstrip('\r\n')
        else: print("") 
        return user_input[0]
    event = threading.Event()
    def keyboard_listener():
        try: user_input[0] = sys.stdin.readline().rstrip('\r\n')
        except: pass
        event.set()
    t = threading.Thread(target=keyboard_listener, daemon=True)
    t.start()
    if not event.wait(timeout): print("") 
    return user_input[0]

def handle_flow_break(next_step_name):
    msg = f" ⚡ [回车]:继续{next_step_name}  [1]:手动模式  [0]:退出: "
    choice = silent_timeout_input(msg, timeout=15, default="").strip()
    if choice == '1':
        custom_menu()
        sys.exit(0)
    elif choice == '0':
        print("\n👋 程序已安全退出。")
        sys.exit(0)

def custom_menu():
    global IS_MANUAL_MODE
    IS_MANUAL_MODE = True
    while True:
        print("\n🛠️  手动模式: [1]重命名 [2]图片水印 [3]视频转码 [4]打包与上传 [0]返回主控")
        ch = input(" 🎯 请输入选择: ").strip()
        if ch == '1': module_rename()
        elif ch == '2': module_watermark()
        elif ch == '3': module_video()
        elif ch == '4': module_pack()
        elif ch == '0': break
        else: print("❌ 无效输入。")

# ==================== 主控启动逻辑 ====================

def main():
    global GLOBAL_ISSUE_NUM, IS_MANUAL_MODE
    IS_MANUAL_MODE = False
    print("🤖 媒体资产流水线整合引擎 (M5 Performance Edition)")
    print(" 🔹 [直接回车] : 开始全套自动化流处理")
    print(" 🔹 [1]        : 进入手动独立运行菜单")
    print(" 🔹 [0]        : 直接安全退出")
    
    init_choice = silent_timeout_input("\n👉 请选择操作: ", timeout=15, default="").strip()
    if init_choice == '1': custom_menu(); return
    elif init_choice == '0': print("👋 程序已退出。"); return

    ensure_global_issue_num()
    if module_rename():
        handle_flow_break("【图片加水印与压缩】")
        if module_watermark():
            video_folder = os.path.join("无水印原图", "V")
            has_video = False
            if os.path.exists(video_folder):
                for f in os.listdir(video_folder):
                    if f.lower().startswith('video-') and os.path.isfile(os.path.join(video_folder, f)):
                        has_video = True; break
            if has_video:
                handle_flow_break("【视频压缩】")
                module_video()
            handle_flow_break("【自动打包】")
            if module_pack():
                # 自动流程在末尾直接触发对应的渠道进行图片/视频高速上传
                trigger_auto_upload_pipeline()
                
    print("\n🎉 所有流水线自动化工作及多线程同步已圆满结束。")

if __name__ == "__main__":
    main()